# Melody Note Maker – Version 1

Android WebView app for selecting MP3, WAV and MP4 files, estimating a single melody line as numbered notes 1–7, editing notes, saving a local draft, and printing to A4 PDF.

## Important limitations
- Automatic pitch detection is experimental and approximate, especially with full mixes, chords, percussion and multiple instruments. Check and edit the result.
- MP4 analysis depends on Android WebView support for the video's audio codec and requires playback to finish.
- The saved project stores song metadata and note edits on the device. The original audio file is not copied into the saved draft; select it again if you need to re-analyze.
- The first version uses a text logo placeholder. A custom logo image can be added later.

## Build
GitHub Actions builds a debug APK using Java 17 and Gradle 8.9.
